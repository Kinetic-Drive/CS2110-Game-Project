/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 vcar V_car.jpg 
 * Time-stamp: Friday 04/09/2021, 21:25:29
 * 
 * Image Information
 * -----------------
 * V_car.jpg 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef VCAR_H
#define VCAR_H

extern const unsigned short V_car[1850];
#define V_CAR_SIZE 3700
#define V_CAR_LENGTH 1850
#define V_CAR_WIDTH 50
#define V_CAR_HEIGHT 37

#endif

