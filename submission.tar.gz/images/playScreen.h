/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 playScreen play_screen.png 
 * Time-stamp: Friday 04/09/2021, 21:31:03
 * 
 * Image Information
 * -----------------
 * play_screen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYSCREEN_H
#define PLAYSCREEN_H

extern const unsigned short play_screen[38400];
#define PLAY_SCREEN_SIZE 76800
#define PLAY_SCREEN_LENGTH 38400
#define PLAY_SCREEN_WIDTH 240
#define PLAY_SCREEN_HEIGHT 160

#endif

